package com.sirmaacademy.app.managers;

public interface Manager {
    void execute(String command);
}
