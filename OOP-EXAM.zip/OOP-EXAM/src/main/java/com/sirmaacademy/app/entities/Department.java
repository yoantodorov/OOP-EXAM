package com.sirmaacademy.app.entities;

public enum Department {
    IT,
    MARKETING,
    HUMAN_RESOURCES,
    ACCOUNTING
}
